import type { SocionicsElement } from './socionics';

export const MEASUREMENT_CHANNELS = [
  'producer',
  'flexible',
  'mask',
  'threat',
  'receiver',
  'aspiration',
  'dismissive',
  'background'
] as const;
export type MeasurementChannel = (typeof MEASUREMENT_CHANNELS)[number];

export const QUESTION_CONTEXTS = [
  'new_situation',
  'group',
  'private',
  'work',
  'friendship',
  'study',
  'public',
  'time_pressure',
  'decision',
  'general',
  'conflict',
  'family',
  'body',
  'romance'
] as const;
export type QuestionContext = (typeof QUESTION_CONTEXTS)[number];

export const SCALE_FAMILIES = ['automaticity', 'comfort', 'threat', 'relief', 'recognition', 'frequency', 'importance'] as const;
export type ScaleFamily = (typeof SCALE_FAMILIES)[number];

export type TestMode = 'ringkas' | 'standar' | 'mendalam';

export type Psychometrics = {
  ambiguity: number;
  intensity: number;
  discrimination: number;
  socialDesirability: number;
  extremityRisk: number;
};

export type RatingOption = {
  value: 1 | 2 | 3 | 4 | 5;
  label: string;
  meaning: string;
  reaction: string;
  score: {
    direction: -1 | 0 | 1;
    intensity: number;
    reliability: number;
  };
};

export type QuestionItem = {
  id: string;
  kind: 'core' | 'holdout' | 'tieBreak';
  element: SocionicsElement;
  channel: MeasurementChannel;
  context: QuestionContext;
  scaleFamily: ScaleFamily;
  statementOriginal: string;
  statementCasual: string;
  responseFocus: string;
  options: RatingOption[];
  psychometrics: Psychometrics;
  version: string;
  pairKey?: string;
};

export type Answer = {
  itemId: string;
  value: 1 | 2 | 3 | 4 | 5;
  answeredAt: number;
  elapsedMs?: number;
};

export type SessionState = {
  sessionId: string;
  mode: TestMode;
  seed: number;
  startedAt: number;
  updatedAt: number;
  currentIndex: number;
  activeItemIds: string[];
  answers: Record<string, Answer>;
  skippedItemIds: string[];
  completedAt: number | null;
  appVersion: string;
};

export type ModeConfig = {
  mode: TestMode;
  title: string;
  itemCount: number;
  estimate: string;
  description: string;
};
