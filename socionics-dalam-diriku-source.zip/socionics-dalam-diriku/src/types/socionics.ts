export const SOCIONICS_ELEMENTS = ['Ne', 'Ni', 'Se', 'Si', 'Te', 'Ti', 'Fe', 'Fi'] as const;
export type SocionicsElement = (typeof SOCIONICS_ELEMENTS)[number];

export const QUADRAS = ['Alpha', 'Beta', 'Gamma', 'Delta'] as const;
export type Quadra = (typeof QUADRAS)[number];

export const SOCIONICS_TYPES = [
  'ILE', 'SEI', 'ESE', 'LII',
  'EIE', 'LSI', 'SLE', 'IEI',
  'SEE', 'ILI', 'LIE', 'ESI',
  'IEE', 'SLI', 'LSE', 'EII'
] as const;
export type SocionicsType = (typeof SOCIONICS_TYPES)[number];

export const MODEL_A_SLOTS = [
  'base',
  'creative',
  'role',
  'vulnerable',
  'suggestive',
  'mobilizing',
  'ignoring',
  'demonstrative'
] as const;
export type ModelASlot = (typeof MODEL_A_SLOTS)[number];

export type ModelAMap = Record<ModelASlot, SocionicsElement>;

export const SLOT_LABELS: Record<ModelASlot, string> = {
  base: 'Base',
  creative: 'Creative',
  role: 'Role',
  vulnerable: 'Vulnerable',
  suggestive: 'Suggestive',
  mobilizing: 'Mobilizing',
  ignoring: 'Ignoring',
  demonstrative: 'Demonstrative'
};

export const SLOT_PUBLIC_LABELS: Record<ModelASlot, string> = {
  base: 'Pusat otomatis',
  creative: 'Alat luwes',
  role: 'Topeng sosial',
  vulnerable: 'Area paling rawan',
  suggestive: 'Kebutuhan yang melegakan',
  mobilizing: 'Dorongan tumbuh',
  ignoring: 'Kemampuan yang sering dilewati',
  demonstrative: 'Keahlian latar'
};

export type ElementDescription = {
  element: SocionicsElement;
  publicName: string;
  shortName: string;
  theme: string;
  signals: string[];
  notThis: string[];
  resultLanguage: string;
};

export type QuadraProfile = {
  quadra: Quadra;
  types: SocionicsType[];
  valuedElements: SocionicsElement[];
  climate: string;
  socialMood: string;
  strengths: string[];
  cautions: string[];
};

export type TypeProfile = {
  code: SocionicsType;
  fullName: string;
  quadra: Quadra;
  modelA: ModelAMap;
  oneLine: string;
  corePattern: string;
  baseDescription: string;
  creativeDescription: string;
  roleMask: string;
  vulnerableRisk: string;
  suggestiveNeed: string;
  mobilizingDrive: string;
  ignoringStyle: string;
  demonstrativeSkill: string;
  strengths: string[];
  drains: string[];
  reliefNeeds: string[];
  developmentNotes: string[];
  commonMistypes: SocionicsType[];
  stereotypeBlock: string;
  notADiagnosisNote: string;
};

export type RelationName =
  | 'Identity'
  | 'Duality'
  | 'Activation'
  | 'Mirror'
  | 'Kindred'
  | 'Semi-duality'
  | 'Mirage'
  | 'Business'
  | 'Contrary'
  | 'Superego'
  | 'Quasi-identity'
  | 'Conflict'
  | 'Supervision'
  | 'Reverse supervision'
  | 'Benefit'
  | 'Reverse benefit';

export type IntertypeRelation = {
  from: SocionicsType;
  to: SocionicsType;
  relation: RelationName;
  tone: string;
  directional: boolean;
};
