import type { ModelAMap, ModelASlot, Quadra, SocionicsElement, SocionicsType } from './socionics';
import type { MeasurementChannel, QuestionContext } from './questions';

export type EvidenceCell = {
  answeredCount: number;
  weightedMean: number | null;
  rawSum: number;
  contexts: QuestionContext[];
  missing: boolean;
  reliabilityWeight: number;
};

export type ChannelProfile = Record<SocionicsElement, Record<MeasurementChannel, EvidenceCell>>;

export type RankedType = {
  type: SocionicsType;
  fitIndex: number;
  relativeSupport: number;
  marginFromNext?: number;
  coreFit: number;
  holdoutAdjustment: number;
  tieBreakAdjustment: number;
};

export type ConfidenceReport = {
  label: 'tidak cukup bukti' | 'rendah' | 'sedang' | 'cukup kuat' | 'kuat secara internal';
  score: number;
  reasons: string[];
};

export type MissingCoverage = {
  missingCells: number;
  answeredCells: number;
  totalCells: 64;
};

export type ElementScore = {
  element: SocionicsElement;
  label: string;
  score: number;
  strongestChannels: MeasurementChannel[];
};

export type ValuedPattern = {
  valued: SocionicsElement[];
  unvalued: SocionicsElement[];
  note: string;
};

export type QuadraReport = {
  primary: Quadra | null;
  support: Record<Quadra, number>;
  note: string;
};

export type SlotReading = {
  slot: ModelASlot;
  element: SocionicsElement;
  label: string;
  note: string;
  evidence: number;
};

export type ResponseBiasReport = {
  warnings: string[];
  straightlining: boolean;
  midpointOveruse: boolean;
  extremeOveruse: boolean;
  speeding: boolean;
  lowCompletion: boolean;
  scorePenalty: number;
};

export type FinalResult = {
  primaryType: SocionicsType | null;
  rankedTypes: RankedType[];
  top3: RankedType[];
  confidence: ConfidenceReport;
  elementRanking: ElementScore[];
  channelProfile: ChannelProfile;
  modelA: ModelAMap | null;
  slotReadings: SlotReading[];
  quadra: QuadraReport;
  valuedPattern: ValuedPattern | null;
  warnings: string[];
  contradictionNotes: string[];
  biasReport: ResponseBiasReport;
  missingCoverage: MissingCoverage;
  holdoutUsed: number;
  unresolvedPair: string | null;
  interpretation: {
    summary: string;
    strengths: string[];
    drains: string[];
    reliefNeeds: string[];
    developmentNotes: string[];
    disclaimer: string;
  };
};
