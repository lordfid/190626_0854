export type AppRoute = 'landing' | 'test' | 'result' | 'card' | 'methodology';
