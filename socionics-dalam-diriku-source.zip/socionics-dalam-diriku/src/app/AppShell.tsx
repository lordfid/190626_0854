import React from 'react';

type Props = { children: React.ReactNode };

export function AppShell({ children }: Props) {
  return <div className="app-shell">{children}</div>;
}
