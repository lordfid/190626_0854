import { toBlob } from 'html-to-image';
import { sanitizeFilename } from './sanitizeFilename';

async function waitForImages(root: HTMLElement): Promise<void> {
  const images = Array.from(root.querySelectorAll('img'));
  await Promise.all(images.map((img) => {
    if (img.complete && img.naturalWidth > 0) return Promise.resolve();
    return new Promise<void>((resolve) => {
      img.onload = () => resolve();
      img.onerror = () => resolve();
    });
  }));
}

export async function exportElementAsPng(element: HTMLElement, filenameBase: string): Promise<File> {
  await waitForImages(element);
  const blob = await toBlob(element, {
    cacheBust: true,
    pixelRatio: 2,
    backgroundColor: 'transparent'
  });
  if (!blob) throw new Error('Kartu belum berhasil dibuat.');
  const file = new File([blob], `${sanitizeFilename(filenameBase)}.png`, { type: 'image/png' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = file.name;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
  return file;
}

export async function shareElementAsPng(element: HTMLElement, filenameBase: string): Promise<'shared' | 'downloaded'> {
  await waitForImages(element);
  const blob = await toBlob(element, { cacheBust: true, pixelRatio: 2, backgroundColor: 'transparent' });
  if (!blob) throw new Error('Kartu belum berhasil dibuat.');
  const file = new File([blob], `${sanitizeFilename(filenameBase)}.png`, { type: 'image/png' });
  if (navigator.canShare?.({ files: [file] })) {
    await navigator.share({ files: [file], title: 'Socionics Dalam Diriku', text: 'Kartu hasil Socionics Dalam Diriku' });
    return 'shared';
  }
  await exportElementAsPng(element, filenameBase);
  return 'downloaded';
}
