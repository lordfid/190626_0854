const ACCEPTED = ['image/jpeg', 'image/png', 'image/webp'];
const MAX_BYTES = 8 * 1024 * 1024;

export function imageToDataUrl(file: File): Promise<string> {
  if (!ACCEPTED.includes(file.type)) {
    return Promise.reject(new Error('Format foto harus JPG, PNG, atau WEBP.'));
  }
  if (file.size > MAX_BYTES) {
    return Promise.reject(new Error('Ukuran foto maksimal 8 MB.'));
  }
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => typeof reader.result === 'string' ? resolve(reader.result) : reject(new Error('Foto tidak bisa dibaca.'));
    reader.onerror = () => reject(new Error('Foto tidak bisa dibaca.'));
    reader.readAsDataURL(file);
  });
}
