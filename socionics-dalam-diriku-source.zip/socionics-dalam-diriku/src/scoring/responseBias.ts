import type { Answer, QuestionItem, SessionState } from '../types/questions';
import type { ResponseBiasReport } from '../types/results';
import { clamp } from '../utils/clamp';

export function checkResponseBias(session: SessionState, activeQuestions: QuestionItem[]): ResponseBiasReport {
  const answers = Object.values(session.answers);
  const values = answers.map((answer) => answer.value);
  const answered = values.length;
  const total = Math.max(1, activeQuestions.length);
  const counts = values.reduce((acc, value) => {
    acc[value] = (acc[value] ?? 0) + 1;
    return acc;
  }, {} as Record<number, number>);
  const mostCommon = Math.max(0, ...Object.values(counts));
  const midpoint = counts[3] ?? 0;
  const extremes = (counts[1] ?? 0) + (counts[5] ?? 0);
  const elapsedAnswers = answers.filter((answer): answer is Answer & { elapsedMs: number } => typeof answer.elapsedMs === 'number');
  const fastCount = elapsedAnswers.filter((answer) => answer.elapsedMs < 900).length;

  const straightlining = answered >= 12 && mostCommon / answered >= 0.82;
  const midpointOveruse = answered >= 12 && midpoint / answered >= 0.62;
  const extremeOveruse = answered >= 12 && extremes / answered >= 0.78;
  const speeding = elapsedAnswers.length >= 12 && fastCount / elapsedAnswers.length >= 0.55;
  const lowCompletion = answered / total < 0.55;

  const warnings: string[] = [];
  if (straightlining) warnings.push('Pola jawaban terlalu seragam, jadi sistem sulit membedakan kandidat dengan aman.');
  if (midpointOveruse) warnings.push('Banyak jawaban berada di tengah, sehingga hasil lebih aman dibaca sebagai kecenderungan lebar.');
  if (extremeOveruse) warnings.push('Jawaban ekstrem muncul sangat sering; confidence diturunkan agar hasil tidak terlalu percaya diri.');
  if (speeding) warnings.push('Beberapa jawaban terlihat sangat cepat; hasil mungkin lebih dangkal dari pola asli.');
  if (lowCompletion) warnings.push('Cakupan jawaban masih rendah; beberapa kanal bukti belum cukup terisi.');

  const scorePenalty = clamp(
    (straightlining ? 0.3 : 0) +
      (midpointOveruse ? 0.18 : 0) +
      (extremeOveruse ? 0.15 : 0) +
      (speeding ? 0.12 : 0) +
      (lowCompletion ? 0.22 : 0),
    0,
    0.65
  );

  return { warnings, straightlining, midpointOveruse, extremeOveruse, speeding, lowCompletion, scorePenalty };
}
