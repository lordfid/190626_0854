import { SOCIONICS_ELEMENTS } from '../types/socionics';
import { MEASUREMENT_CHANNELS } from '../types/questions';
import type { Answer, QuestionItem } from '../types/questions';
import type { ChannelProfile, EvidenceCell } from '../types/results';

function emptyCell(): EvidenceCell {
  return { answeredCount: 0, weightedMean: null, rawSum: 0, contexts: [], missing: true, reliabilityWeight: 0 };
}

export function createEmptyChannelProfile(): ChannelProfile {
  return SOCIONICS_ELEMENTS.reduce((elementAcc, element) => {
    elementAcc[element] = MEASUREMENT_CHANNELS.reduce((channelAcc, channel) => {
      channelAcc[channel] = emptyCell();
      return channelAcc;
    }, {} as ChannelProfile[typeof element]);
    return elementAcc;
  }, {} as ChannelProfile);
}

export function calculateRawSignals(answers: Answer[], questions: Record<string, QuestionItem>): ChannelProfile {
  const profile = createEmptyChannelProfile();
  for (const answer of answers) {
    const item = questions[answer.itemId];
    if (!item) continue;
    const option = item.options.find((candidate) => candidate.value === answer.value);
    if (!option) continue;
    const cell = profile[item.element][item.channel];
    const discrimination = item.psychometrics.discrimination;
    const desirabilityPenalty = 1 - item.psychometrics.socialDesirability * 0.22;
    const reliability = option.score.reliability * discrimination * desirabilityPenalty;
    const signedSignal = option.score.direction * option.score.intensity;
    cell.answeredCount += 1;
    cell.rawSum += signedSignal * reliability;
    cell.reliabilityWeight += reliability;
    if (!cell.contexts.includes(item.context)) cell.contexts.push(item.context);
    cell.missing = false;
    cell.weightedMean = cell.reliabilityWeight > 0 ? cell.rawSum / cell.reliabilityWeight : null;
  }
  return profile;
}
