import type { Answer, QuestionItem, SessionState } from '../types/questions';
import type { FinalResult, QuadraReport, ValuedPattern } from '../types/results';
import type { Quadra } from '../types/socionics';
import { QUADRAS } from '../types/socionics';
import { MODEL_A_BY_TYPE, QUADRA_VALUED_ELEMENTS, TYPE_QUADRA } from '../data/socionicsModelA';
import { TYPE_PROFILES } from '../data/typeProfiles';
import { ELEMENT_DESCRIPTIONS } from '../data/elementDescriptions';
import { DISCLAIMER } from '../data/resultCopy';
import { calculateRawSignals } from './rawSignals';
import { calculateModelFit, calculateElementRanking, createSlotReadings } from './modelFit';
import { applyHoldoutAdjustment } from './holdout';
import { applyTieBreakAdjustment, canonicalPair } from './tieBreak';
import { checkResponseBias } from './responseBias';
import { detectContradictions } from './contradiction';
import { calculateConfidence, coverageFromProfile } from './confidence';

function createQuadraReport(rankedTypes: FinalResult['rankedTypes']): QuadraReport {
  const support = QUADRAS.reduce((acc, quadra) => {
    acc[quadra] = 0;
    return acc;
  }, {} as Record<Quadra, number>);
  const topRows = rankedTypes.slice(0, 8);
  for (const row of topRows) support[TYPE_QUADRA[row.type]] += row.relativeSupport;
  const primary = QUADRAS.slice().sort((a, b) => support[b] - support[a])[0] ?? null;
  return {
    primary,
    support,
    note: primary ? `Pola kandidat paling banyak berkumpul di ${primary}, tetapi ini dibaca sebagai iklim nilai, bukan bonus skor ganda.` : 'Belum cukup kandidat untuk membaca iklim nilai.'
  };
}

function createValuedPattern(primaryType: FinalResult['primaryType']): ValuedPattern | null {
  if (!primaryType) return null;
  const quadra = TYPE_QUADRA[primaryType];
  const valued = QUADRA_VALUED_ELEMENTS[quadra];
  const unvalued = Object.keys(ELEMENT_DESCRIPTIONS).filter((element) => !valued.includes(element as never)) as ValuedPattern['unvalued'];
  return {
    valued,
    unvalued,
    note: `Pada kandidat utama, unsur yang lebih mungkin terasa bernilai adalah ${valued.join(', ')}. Unsur lain tetap bisa kuat, tetapi tidak selalu terasa perlu dijadikan pusat.`
  };
}

function createEmptyResult(session: SessionState, activeQuestions: QuestionItem[]): FinalResult {
  const profile = calculateRawSignals([], {});
  const biasReport = checkResponseBias(session, activeQuestions);
  const missingCoverage = coverageFromProfile(profile);
  return {
    primaryType: null,
    rankedTypes: [],
    top3: [],
    confidence: { label: 'tidak cukup bukti', score: 0, reasons: ['Belum cukup jawaban untuk membaca pola Socionics-mu.'] },
    elementRanking: calculateElementRanking(profile),
    channelProfile: profile,
    modelA: null,
    slotReadings: [],
    quadra: { primary: null, support: { Alpha: 0, Beta: 0, Gamma: 0, Delta: 0 }, note: 'Belum cukup bukti.' },
    valuedPattern: null,
    warnings: ['Belum cukup bukti untuk menampilkan tipe utama dengan aman.'],
    contradictionNotes: [],
    biasReport,
    missingCoverage,
    holdoutUsed: 0,
    unresolvedPair: null,
    interpretation: {
      summary: 'Belum cukup bukti untuk membaca pola Socionics-mu. Isi beberapa bagian lagi atau mulai ulang sesi dengan lebih pelan.',
      strengths: [],
      drains: [],
      reliefNeeds: [],
      developmentNotes: [],
      disclaimer: DISCLAIMER
    }
  };
}

export function calculateFinalResult(session: SessionState, questionMap: Record<string, QuestionItem>): FinalResult {
  const activeQuestions = session.activeItemIds.map((id) => questionMap[id]).filter((item): item is QuestionItem => Boolean(item));
  const answers: Answer[] = Object.values(session.answers).filter((answer) => Boolean(questionMap[answer.itemId]));
  if (answers.length < 18) return createEmptyResult(session, activeQuestions);

  const profile = calculateRawSignals(answers, questionMap);
  let rankedTypes = calculateModelFit(profile);
  const holdout = applyHoldoutAdjustment(rankedTypes, answers, questionMap);
  rankedTypes = applyTieBreakAdjustment(holdout.ranked, answers, questionMap);
  const top = rankedTypes[0];
  const second = rankedTypes[1];
  const unresolvedPair = top && second && (top.marginFromNext ?? 0) < 0.035 ? canonicalPair(top.type, second.type) : null;
  const biasReport = checkResponseBias(session, activeQuestions);
  const contradictionNotes = detectContradictions(profile);
  const confidence = calculateConfidence({ profile, answers, activeQuestions, rankedTypes, bias: biasReport, contradictionCount: contradictionNotes.length, holdoutUsed: holdout.used });
  const missingCoverage = coverageFromProfile(profile);
  const primaryType = confidence.label === 'tidak cukup bukti' ? null : top?.type ?? null;
  const modelA = primaryType ? MODEL_A_BY_TYPE[primaryType] : null;
  const typeProfile = primaryType ? TYPE_PROFILES[primaryType] : null;
  const warnings = [...biasReport.warnings];
  if (missingCoverage.missingCells > 0) warnings.push(`${missingCoverage.missingCells} dari 64 kanal belum terisi, jadi confidence disesuaikan.`);
  if (unresolvedPair) warnings.push('Dua kandidat teratas masih rapat. Hasil ini lebih aman dibaca sebagai area kemungkinan, bukan keputusan final.');
  if (confidence.label === 'tidak cukup bukti') warnings.push('Pola jawaban belum cukup aman untuk memunculkan tipe utama.');

  return {
    primaryType,
    rankedTypes,
    top3: rankedTypes.slice(0, 3),
    confidence,
    elementRanking: calculateElementRanking(profile),
    channelProfile: profile,
    modelA,
    slotReadings: createSlotReadings(primaryType, profile),
    quadra: createQuadraReport(rankedTypes),
    valuedPattern: createValuedPattern(primaryType),
    warnings,
    contradictionNotes,
    biasReport,
    missingCoverage,
    holdoutUsed: holdout.used,
    unresolvedPair,
    interpretation: {
      summary: typeProfile ? `${typeProfile.oneLine} Bacaan ini menonjol sebagai pola yang tampak, bukan vonis final.` : 'Belum cukup bukti untuk membaca pola Socionics-mu dengan aman.',
      strengths: typeProfile?.strengths ?? [],
      drains: typeProfile?.drains ?? [],
      reliefNeeds: typeProfile?.reliefNeeds ?? [],
      developmentNotes: typeProfile?.developmentNotes ?? [],
      disclaimer: DISCLAIMER
    }
  };
}
