import type { Answer, QuestionItem } from '../types/questions';
import type { ChannelProfile, ConfidenceReport, RankedType, ResponseBiasReport } from '../types/results';
import { SOCIONICS_ELEMENTS } from '../types/socionics';
import { MEASUREMENT_CHANNELS } from '../types/questions';
import { clamp } from '../utils/clamp';

export function coverageFromProfile(profile: ChannelProfile) {
  let answeredCells = 0;
  for (const element of SOCIONICS_ELEMENTS) {
    for (const channel of MEASUREMENT_CHANNELS) {
      if (!profile[element][channel].missing) answeredCells += 1;
    }
  }
  return { answeredCells, missingCells: 64 - answeredCells, totalCells: 64 as const };
}

export function calculateConfidence(args: {
  profile: ChannelProfile;
  answers: Answer[];
  activeQuestions: QuestionItem[];
  rankedTypes: RankedType[];
  bias: ResponseBiasReport;
  contradictionCount: number;
  holdoutUsed: number;
}): ConfidenceReport {
  const coverage = coverageFromProfile(args.profile);
  const completion = args.answers.length / Math.max(1, args.activeQuestions.length);
  const coverageScore = coverage.answeredCells / 64;
  const margin = args.rankedTypes[0]?.marginFromNext ?? 0;
  const marginScore = clamp(margin / 0.12, 0, 1);
  const answerVolumeScore = clamp(args.answers.length / 80, 0, 1);
  const holdoutScore = clamp(args.holdoutUsed / 16, 0, 1);
  const contradictionPenalty = clamp(args.contradictionCount * 0.06, 0, 0.35);

  let score = 0.34 * coverageScore + 0.22 * completion + 0.18 * marginScore + 0.16 * answerVolumeScore + 0.1 * holdoutScore;
  score = clamp(score - args.bias.scorePenalty - contradictionPenalty, 0, 1);

  const reasons: string[] = [];
  if (coverage.answeredCells < 48) reasons.push(`Cakupan baru ${coverage.answeredCells}/64 kanal, sehingga beberapa area belum terbaca.`);
  if (completion < 0.7) reasons.push('Sebagian item belum dijawab, jadi hasil lebih aman dibaca sebagai hipotesis awal.');
  if (margin < 0.035 && args.rankedTypes.length > 1) reasons.push('Dua kandidat teratas masih rapat.');
  if (args.bias.warnings.length) reasons.push(...args.bias.warnings.slice(0, 3));
  if (args.contradictionCount > 0) reasons.push('Ada beberapa sinyal yang saling tarik-menarik antar konteks.');
  if (!reasons.length) reasons.push('Cakupan, jarak kandidat, dan pola jawaban cukup rapi secara internal.');

  const tooSparse = args.answers.length < 18 || coverage.answeredCells < 20 || args.bias.straightlining;
  if (tooSparse) return { label: 'tidak cukup bukti', score: 0, reasons };
  if (score < 0.32) return { label: 'rendah', score, reasons };
  if (score < 0.56) return { label: 'sedang', score, reasons };
  if (score < 0.78) return { label: 'cukup kuat', score, reasons };
  return { label: 'kuat secara internal', score, reasons };
}
