import type { Answer, QuestionItem } from '../types/questions';
import type { RankedType } from '../types/results';
import { MODEL_A_BY_TYPE } from '../data/socionicsModelA';
import { getSlotForElement } from '../data/socionicsModelA';

const SLOT_SUPPORT = {
  base: 0.85,
  creative: 0.7,
  role: 0.2,
  vulnerable: -0.75,
  suggestive: 0.25,
  mobilizing: 0.35,
  ignoring: 0.15,
  demonstrative: 0.45
};

export function applyHoldoutAdjustment(ranked: RankedType[], answers: Answer[], questions: Record<string, QuestionItem>): { ranked: RankedType[]; used: number } {
  const holdoutAnswers = answers.filter((answer) => questions[answer.itemId]?.kind === 'holdout');
  if (holdoutAnswers.length === 0) return { ranked, used: 0 };
  const adjusted = ranked.map((row) => {
    let raw = 0;
    let possible = 0;
    for (const answer of holdoutAnswers) {
      const item = questions[answer.itemId];
      const option = item?.options.find((candidate) => candidate.value === answer.value);
      if (!item || !option) continue;
      const slot = getSlotForElement(row.type, item.element);
      if (!slot) continue;
      const signed = option.score.direction * option.score.intensity;
      const expected = SLOT_SUPPORT[slot];
      const weight = option.score.reliability * item.psychometrics.discrimination;
      raw += signed * expected * weight;
      possible += Math.abs(expected) * weight;
    }
    const normalized = possible > 0 ? raw / possible : 0;
    const holdoutAdjustment = Math.max(-0.12, Math.min(0.12, normalized * 0.12));
    return { ...row, fitIndex: Math.max(0, Math.min(1, row.fitIndex + holdoutAdjustment)), holdoutAdjustment };
  }).sort((a, b) => b.fitIndex - a.fitIndex);
  return { ranked: adjusted, used: holdoutAnswers.length };
}
