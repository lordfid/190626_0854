import { clamp } from '../utils/clamp';

export function normalizeFit(raw: number, possible: number): number {
  if (possible <= 0) return 0;
  return clamp((raw / possible + 1) / 2, 0, 1);
}

export function asPercent(value: number): number {
  return Math.round(clamp(value, 0, 1) * 100);
}
