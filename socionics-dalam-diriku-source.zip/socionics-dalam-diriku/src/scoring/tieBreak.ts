import type { Answer, QuestionItem } from '../types/questions';
import type { RankedType } from '../types/results';
import type { SocionicsType } from '../types/socionics';

export function canonicalPair(a: SocionicsType, b: SocionicsType): string {
  return [a, b].sort().join('_');
}

export function applyTieBreakAdjustment(ranked: RankedType[], answers: Answer[], questions: Record<string, QuestionItem>): RankedType[] {
  const top = ranked[0];
  const second = ranked[1];
  if (!top || !second) return ranked;
  const pairKey = canonicalPair(top.type, second.type);
  const pairAnswers = answers.filter((answer) => questions[answer.itemId]?.pairKey === pairKey);
  if (pairAnswers.length === 0) return ranked;
  const direction = top.type < second.type ? 1 : -1;
  const raw = pairAnswers.reduce((sum, answer) => {
    const item = questions[answer.itemId];
    const option = item?.options.find((candidate) => candidate.value === answer.value);
    if (!option) return sum;
    return sum + option.score.direction * option.score.intensity * option.score.reliability * direction;
  }, 0);
  const adjustment = Math.max(-0.02, Math.min(0.02, raw / Math.max(1, pairAnswers.length) * 0.02));
  return ranked.map((row) => {
    if (row.type === top.type) return { ...row, fitIndex: Math.max(0, Math.min(1, row.fitIndex + adjustment)), tieBreakAdjustment: adjustment };
    if (row.type === second.type) return { ...row, fitIndex: Math.max(0, Math.min(1, row.fitIndex - adjustment)), tieBreakAdjustment: -adjustment };
    return row;
  }).sort((a, b) => b.fitIndex - a.fitIndex);
}
