import { MODEL_A_SLOTS, SOCIONICS_ELEMENTS, SOCIONICS_TYPES, SLOT_PUBLIC_LABELS } from '../types/socionics';
import type { ModelASlot, SocionicsElement, SocionicsType } from '../types/socionics';
import { MEASUREMENT_CHANNELS } from '../types/questions';
import type { MeasurementChannel } from '../types/questions';
import type { ChannelProfile, ElementScore, RankedType, SlotReading } from '../types/results';
import { ELEMENT_DESCRIPTIONS } from '../data/elementDescriptions';
import { MODEL_A_BY_TYPE } from '../data/socionicsModelA';
import { SLOT_RESULT_NOTES } from '../data/resultCopy';
import { normalizeFit } from './normalize';

const EXPECTED_BY_SLOT: Record<ModelASlot, Record<MeasurementChannel, number>> = {
  base: { producer: 1, flexible: 0.35, mask: -0.25, threat: -0.85, receiver: -0.35, aspiration: 0.1, dismissive: 0.2, background: 0.45 },
  creative: { producer: 0.45, flexible: 1, mask: -0.1, threat: -0.45, receiver: -0.15, aspiration: 0.25, dismissive: 0.05, background: 0.35 },
  role: { producer: -0.05, flexible: -0.15, mask: 1, threat: 0.35, receiver: 0.1, aspiration: 0.2, dismissive: -0.35, background: -0.1 },
  vulnerable: { producer: -0.75, flexible: -0.55, mask: 0.35, threat: 1, receiver: 0.25, aspiration: -0.15, dismissive: -0.25, background: -0.75 },
  suggestive: { producer: -0.45, flexible: -0.15, mask: 0.05, threat: 0.25, receiver: 1, aspiration: 0.35, dismissive: -0.25, background: -0.35 },
  mobilizing: { producer: 0.1, flexible: 0.25, mask: 0.2, threat: 0.05, receiver: 0.25, aspiration: 1, dismissive: -0.15, background: 0.05 },
  ignoring: { producer: 0.25, flexible: 0.1, mask: -0.15, threat: -0.25, receiver: -0.25, aspiration: -0.25, dismissive: 1, background: 0.35 },
  demonstrative: { producer: 0.35, flexible: 0.25, mask: -0.25, threat: -0.35, receiver: -0.2, aspiration: -0.1, dismissive: 0.35, background: 1 }
};

function slotFor(type: SocionicsType, element: SocionicsElement): ModelASlot {
  const map = MODEL_A_BY_TYPE[type];
  const slot = MODEL_A_SLOTS.find((candidate) => map[candidate] === element);
  if (!slot) throw new Error(`Missing slot for ${type} ${element}`);
  return slot;
}

export function calculateModelFit(profile: ChannelProfile): RankedType[] {
  const rawRows = SOCIONICS_TYPES.map((type) => {
    let raw = 0;
    let possible = 0;
    for (const element of SOCIONICS_ELEMENTS) {
      const slot = slotFor(type, element);
      for (const channel of MEASUREMENT_CHANNELS) {
        const cell = profile[element][channel];
        if (cell.missing || cell.weightedMean === null) continue;
        const expected = EXPECTED_BY_SLOT[slot][channel];
        const weight = Math.max(0.2, cell.reliabilityWeight / Math.max(1, cell.answeredCount));
        raw += cell.weightedMean * expected * weight;
        possible += Math.abs(expected) * weight;
      }
    }
    const coreFit = normalizeFit(raw, possible);
    return { type, coreFit };
  });

  const sorted = rawRows.sort((a, b) => b.coreFit - a.coreFit);
  const min = Math.min(...sorted.map((row) => row.coreFit));
  const max = Math.max(...sorted.map((row) => row.coreFit));
  return sorted.map((row, index) => ({
    type: row.type,
    fitIndex: row.coreFit,
    coreFit: row.coreFit,
    relativeSupport: max === min ? 0 : (row.coreFit - min) / (max - min),
    marginFromNext: index < sorted.length - 1 ? row.coreFit - sorted[index + 1].coreFit : undefined,
    holdoutAdjustment: 0,
    tieBreakAdjustment: 0
  }));
}

export function calculateElementRanking(profile: ChannelProfile): ElementScore[] {
  return SOCIONICS_ELEMENTS.map((element) => {
    const cells = MEASUREMENT_CHANNELS.map((channel) => ({ channel, cell: profile[element][channel] }))
      .filter(({ cell }) => !cell.missing && cell.weightedMean !== null);
    const score = cells.length === 0 ? 0 : cells.reduce((sum, { cell }) => sum + Math.abs(cell.weightedMean ?? 0) * cell.reliabilityWeight, 0) / cells.reduce((sum, { cell }) => sum + Math.max(0.001, cell.reliabilityWeight), 0);
    const strongestChannels = cells
      .sort((a, b) => Math.abs(b.cell.weightedMean ?? 0) - Math.abs(a.cell.weightedMean ?? 0))
      .slice(0, 3)
      .map(({ channel }) => channel);
    return { element, label: ELEMENT_DESCRIPTIONS[element].publicName, score, strongestChannels };
  }).sort((a, b) => b.score - a.score);
}

export function createSlotReadings(type: SocionicsType | null, profile: ChannelProfile): SlotReading[] {
  if (!type) return [];
  const map = MODEL_A_BY_TYPE[type];
  return MODEL_A_SLOTS.map((slot) => {
    const element = map[slot];
    const cells = MEASUREMENT_CHANNELS.map((channel) => profile[element][channel]).filter((cell) => !cell.missing && cell.weightedMean !== null);
    const evidence = cells.length === 0 ? 0 : cells.reduce((sum, cell) => sum + Math.abs(cell.weightedMean ?? 0), 0) / cells.length;
    return { slot, element, label: SLOT_PUBLIC_LABELS[slot], note: SLOT_RESULT_NOTES[slot], evidence };
  });
}
