import { SOCIONICS_ELEMENTS } from '../types/socionics';
import { MEASUREMENT_CHANNELS } from '../types/questions';
import type { ChannelProfile } from '../types/results';
import { ELEMENT_DESCRIPTIONS } from '../data/elementDescriptions';

export function detectContradictions(profile: ChannelProfile): string[] {
  const notes: string[] = [];
  for (const element of SOCIONICS_ELEMENTS) {
    const producer = profile[element].producer.weightedMean;
    const threat = profile[element].threat.weightedMean;
    const receiver = profile[element].receiver.weightedMean;
    const dismissive = profile[element].dismissive.weightedMean;
    if (producer !== null && threat !== null && producer > 0.55 && threat > 0.55) {
      notes.push(`${ELEMENT_DESCRIPTIONS[element].publicName}: ada sinyal otomatis sekaligus tegang. Ini bisa berarti konteksnya bercampur, bukan langsung tipe tunggal.`);
    }
    if (receiver !== null && dismissive !== null && receiver > 0.55 && dismissive > 0.55) {
      notes.push(`${ELEMENT_DESCRIPTIONS[element].publicName}: kamu tampak terbantu oleh area ini, tetapi juga sering menganggapnya tidak perlu dibesarkan.`);
    }
    const answeredCells = MEASUREMENT_CHANNELS.filter((channel) => !profile[element][channel].missing);
    if (answeredCells.length >= 6) {
      const positives = answeredCells.filter((channel) => (profile[element][channel].weightedMean ?? 0) > 0.6).length;
      const negatives = answeredCells.filter((channel) => (profile[element][channel].weightedMean ?? 0) < -0.6).length;
      if (positives >= 3 && negatives >= 3) {
        notes.push(`${ELEMENT_DESCRIPTIONS[element].publicName}: sinyalnya menyebar ke dua arah ekstrem; hasil pada area ini perlu dibaca pelan.`);
      }
    }
  }
  return notes.slice(0, 6);
}
