import type { SessionState, TestMode } from '../types/questions';
import { QUESTION_BY_ID } from '../data/questionIndex';
import { APP_VERSION, createSession } from './storage';

const modes: TestMode[] = ['ringkas', 'standar', 'mendalam'];

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value) && typeof value === 'object' && !Array.isArray(value);
}

export function migrateSession(value: unknown): SessionState | null {
  if (!isRecord(value)) return null;
  const mode = modes.includes(value.mode as TestMode) ? (value.mode as TestMode) : 'ringkas';
  if (!Array.isArray(value.activeItemIds)) return createSession(mode);
  const activeItemIds = value.activeItemIds.filter((id): id is string => typeof id === 'string' && Boolean(QUESTION_BY_ID[id]));
  if (!activeItemIds.length) return createSession(mode);
  const answersRaw = isRecord(value.answers) ? value.answers : {};
  const answers: SessionState['answers'] = {};
  for (const [itemId, answer] of Object.entries(answersRaw)) {
    if (!activeItemIds.includes(itemId) || !isRecord(answer)) continue;
    const rating = answer.value;
    if (![1, 2, 3, 4, 5].includes(Number(rating))) continue;
    answers[itemId] = {
      itemId,
      value: Number(rating) as 1 | 2 | 3 | 4 | 5,
      answeredAt: typeof answer.answeredAt === 'number' ? answer.answeredAt : Date.now(),
      elapsedMs: typeof answer.elapsedMs === 'number' ? answer.elapsedMs : undefined
    };
  }
  return {
    sessionId: typeof value.sessionId === 'string' ? value.sessionId : createSession(mode).sessionId,
    mode,
    seed: typeof value.seed === 'number' && Number.isFinite(value.seed) ? value.seed : Date.now(),
    startedAt: typeof value.startedAt === 'number' ? value.startedAt : Date.now(),
    updatedAt: Date.now(),
    currentIndex: Math.min(Math.max(0, typeof value.currentIndex === 'number' ? value.currentIndex : 0), activeItemIds.length - 1),
    activeItemIds,
    answers,
    skippedItemIds: Array.isArray(value.skippedItemIds) ? value.skippedItemIds.filter((id): id is string => typeof id === 'string') : [],
    completedAt: typeof value.completedAt === 'number' ? value.completedAt : null,
    appVersion: APP_VERSION
  };
}
