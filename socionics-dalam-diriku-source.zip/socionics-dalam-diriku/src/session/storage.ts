import type { SessionState, TestMode } from '../types/questions';
import { makeSeed } from '../utils/seededRandom';
import { sampleItems } from './sampler';
import { migrateSession } from './migration';

export const APP_VERSION = '1.0.0';
const STORAGE_KEY = 'socionics-dalam-diriku.session.v1';
const DEBUG_KEY = 'socionics-dalam-diriku.corrupt-backup';

export function createSession(mode: TestMode): SessionState {
  const seed = makeSeed();
  const now = Date.now();
  return {
    sessionId: `sdd-${now.toString(36)}-${Math.floor(seed).toString(36)}`,
    mode,
    seed,
    startedAt: now,
    updatedAt: now,
    currentIndex: 0,
    activeItemIds: sampleItems(mode, seed),
    answers: {},
    skippedItemIds: [],
    completedAt: null,
    appVersion: APP_VERSION
  };
}

export function loadSession(): SessionState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as unknown;
    return migrateSession(parsed);
  } catch {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) localStorage.setItem(DEBUG_KEY, raw);
    localStorage.removeItem(STORAGE_KEY);
    return null;
  }
}

export function saveSession(session: SessionState): void {
  localStorage.setItem(STORAGE_KEY, JSON.stringify({ ...session, updatedAt: Date.now() }));
}

export function clearSession(): void {
  localStorage.removeItem(STORAGE_KEY);
}
