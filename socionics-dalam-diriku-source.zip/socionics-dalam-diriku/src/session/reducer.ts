import type { Answer, SessionState } from '../types/questions';

export function answerItem(session: SessionState, answer: Answer): SessionState {
  if (!session.activeItemIds.includes(answer.itemId)) return session;
  const skippedItemIds = session.skippedItemIds.filter((id) => id !== answer.itemId);
  return { ...session, answers: { ...session.answers, [answer.itemId]: answer }, skippedItemIds, updatedAt: Date.now() };
}

export function skipItem(session: SessionState, itemId: string): SessionState {
  const answers = { ...session.answers };
  delete answers[itemId];
  const skippedItemIds = session.skippedItemIds.includes(itemId) ? session.skippedItemIds : [...session.skippedItemIds, itemId];
  return { ...session, answers, skippedItemIds, updatedAt: Date.now() };
}

export function setCurrentIndex(session: SessionState, currentIndex: number): SessionState {
  return { ...session, currentIndex: Math.min(Math.max(0, currentIndex), session.activeItemIds.length - 1), updatedAt: Date.now() };
}

export function completeSession(session: SessionState): SessionState {
  return { ...session, completedAt: Date.now(), updatedAt: Date.now() };
}
