import type { TestMode } from '../types/questions';
import { CORE_QUESTIONS } from '../data/coreQuestions';
import { HOLDOUT_QUESTIONS } from '../data/holdoutQuestions';
import { TIE_BREAK_QUESTIONS } from '../data/tieBreakQuestions';
import { shuffleSeeded } from '../utils/seededRandom';

export const MODE_ITEM_COUNTS: Record<TestMode, number> = {
  ringkas: 80,
  standar: 128,
  mendalam: 280
};

export function sampleItems(mode: TestMode, seed: number): string[] {
  const firstPerCell = CORE_QUESTIONS.filter((item) => item.id.endsWith('_1'));
  const secondPerCell = CORE_QUESTIONS.filter((item) => item.id.endsWith('_2'));
  const shuffledSecond = shuffleSeeded(secondPerCell, seed + 11);
  const shuffledHoldout = shuffleSeeded(HOLDOUT_QUESTIONS, seed + 23);
  const shuffledTie = shuffleSeeded(TIE_BREAK_QUESTIONS, seed + 37);

  if (mode === 'ringkas') {
    return shuffleSeeded([...firstPerCell, ...shuffledSecond.slice(0, 16)], seed + 3).map((item) => item.id);
  }
  if (mode === 'standar') {
    return shuffleSeeded([...firstPerCell, ...secondPerCell], seed + 5).map((item) => item.id);
  }
  return shuffleSeeded([...firstPerCell, ...secondPerCell, ...shuffledHoldout, ...shuffledTie], seed + 7).map((item) => item.id);
}
