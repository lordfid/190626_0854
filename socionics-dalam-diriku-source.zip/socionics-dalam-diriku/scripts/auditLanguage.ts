import { QUESTION_BANK } from '../src/data/questionIndex';
import { auditQuestionLanguage } from '../src/audit/languageAudit';

const errors = auditQuestionLanguage(QUESTION_BANK);
if (errors.length) {
  for (const error of errors) console.error(`FAIL ${error}`);
  process.exit(1);
}
console.log('Language audit passed.');
