import { runInstrumentAudit } from '../src/audit/instrumentAudit';

const report = runInstrumentAudit();
for (const warning of report.warnings) console.warn(`WARN ${warning}`);
if (!report.passed) {
  for (const error of report.errors) console.error(`FAIL ${error}`);
  process.exit(1);
}
console.log('Audit passed: instrument structure, language guard, mapping, coverage, and relation matrix are valid.');
